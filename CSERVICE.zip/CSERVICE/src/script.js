// 1. Dado dos Explicadores
const explicadores = [
  {
    id: 1,
    nome: "Eng. Manuel Silva",
    especialidade: "Engenharia",
    cadeira: "Cálculo I, II, Física",
    bio: "Especialista em Análise Matemática com 5 anos de experiência ajudando estudantes da UAN e ISPTEC.",
    preco: 5000,
    avaliacao: 4.9,
    img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&h=300&fit=crop"
  },
  {
    id: 2,
    nome: "Drª. Ana Paula",
    especialidade: "Economia",
    cadeira: "Microeconomia, Gestão",
    bio: "Mestre em Finanças pela Católica de Luanda. Foco em clareza conceitual e exercícios práticos.",
    preco: 4500,
    avaliacao: 4.8,
    img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=300&h=300&fit=crop"
  },
  {
    id: 3,
    nome: "Msc. Isaac Bento",
    especialidade: "Tecnologia",
    cadeira: "Programação (Python, C++)",
    bio: "Desenvolvedor Full-Stack. Ensiho desde lógica de programação até estruturas de dados complexas.",
    preco: 6000,
    avaliacao: 5.0,
    img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=300&h=300&fit=crop"
  },
  {
    id: 4,
    nome: "Dr. Domingos K.",
    especialidade: "Saúde",
    cadeira: "Anatomia, Bioquímica",
    bio: "Interno de Medicina. Auxílio intensivo para estudantes do primeiro e segundo ciclo de saúde.",
    preco: 5500,
    avaliacao: 4.7,
    img: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?q=80&w=300&h=300&fit=crop"
  },
  {
    id: 5,
    nome: "Eng. Sílvia Jorge",
    especialidade: "Engenharia",
    cadeira: "Resistência de Materiais",
    bio: "Foco em estudantes de Engenharia Civil e Mecânica. Metodologia baseada em exames passados.",
    preco: 4800,
    avaliacao: 4.9,
    img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&h=300&fit=crop"
  },
  {
    id: 6,
    nome: "Lic. Miguel Ângelo",
    especialidade: "Economia",
    cadeira: "Contabilidade Analítica",
    bio: "Contabilista certificado. Explicações dinâmicas para desbloquear sua compreensão do balanço.",
    preco: 4000,
    avaliacao: 4.6,
    img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=300&h=300&fit=crop"
  }
];

// 2.  DOM
const tutorGrid = document.getElementById('tutor-grid');
const searchInput = document.getElementById('subject-search');
const searchBtn = document.getElementById('search-btn');
const filterBtns = document.querySelectorAll('.filter-btn');
const modal = document.getElementById('booking-modal');
const closeModal = document.querySelector('.close-modal');
const bookingForm = document.getElementById('booking-form');
const modalTutorNameSpan = document.querySelector('#modal-tutor-name span');

// 3. Funçes Principais

function formatCurrency(value) {
  return value.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz');
}

function renderStars(rating) {
  return '★'.repeat(Math.round(rating)) + '☆'.repeat(5 - Math.round(rating));
}

function createTutorCard(tutor) {
  const card = document.createElement('div');
  card.className = 'tutor-card reveal';
  card.setAttribute('data-category', tutor.especialidade);
  
  card.innerHTML = `
    <div class="tutor-img-container">
      <div class="tutor-img" style="background-image: url('${tutor.img}')"></div>
      <div class="tutor-badge">${tutor.especialidade}</div>
    </div>
    <div class="tutor-info">
      <span class="tutor-name">${tutor.nome}</span>
      <span class="tutor-specialty">${tutor.cadeira.split(',')[0]}</span>
      <p class="tutor-bio">${tutor.bio}</p>
      <div class="tutor-footer">
        <div class="tutor-price-box">
          <span class="tutor-price-label">Preço por hora</span>
          <span class="tutor-price">${formatCurrency(tutor.preco)}</span>
        </div>
        <div class="tutor-rating">
          <span style="color: #fbbf24">★</span> ${tutor.avaliacao}
        </div>
      </div>
      <button class="btn btn-primary w-full" style="margin-top: 20px; justify-content: center; width: 100%;" onClick="openBookingModal('${tutor.nome}')">Agendar Agora</button>
    </div>
  `;
  return card;
}

function displayTutors(tutors) {
  tutorGrid.innerHTML = '';
  if (tutors.length === 0) {
    tutorGrid.innerHTML = '<p class="text-center w-full">Nenhum explicador encontrado para sua busca.</p>';
    return;
  }
  tutors.forEach(tutor => {
    tutorGrid.appendChild(createTutorCard(tutor));
  });
}

// 5. Scroll 
function revealOnScroll() {
  const reveals = document.querySelectorAll('.reveal');
  reveals.forEach(element => {
    const windowHeight = window.innerHeight;
    const elementTop = element.getBoundingClientRect().top;
    const elementVisible = 100;
    
    if (elementTop < windowHeight - elementVisible) {
      element.classList.add('active');
    }
  });
}

function filterTutors() {
  const searchTerm = searchInput.value.toLowerCase();
  const activeCategory = document.querySelector('.filter-btn.active').getAttribute('data-category');
  
  const filtered = explicadores.filter(tutor => {
    const matchesSearch = tutor.nome.toLowerCase().includes(searchTerm) || 
                          tutor.cadeira.toLowerCase().includes(searchTerm) ||
                          tutor.especialidade.toLowerCase().includes(searchTerm);
    
    const matchesCategory = activeCategory === 'todos' || tutor.especialidade === activeCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  displayTutors(filtered);
  setTimeout(revealOnScroll, 100); 
}

// 4. Modal de Agendamento
window.openBookingModal = function(tutorName) {
  modalTutorNameSpan.textContent = tutorName;
  modal.style.display = 'block';
  document.body.style.overflow = 'hidden'; 
};

function closeBookingModal() {
  modal.style.display = 'none';
  document.body.style.overflow = 'auto';
}

searchBtn.addEventListener('click', filterTutors);
searchInput.addEventListener('keyup', (e) => {
  if (e.key === 'Enter') filterTutors();
});

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    filterTutors();
  });
});

closeModal.addEventListener('click', closeBookingModal);

window.addEventListener('click', (e) => {
  if (e.target === modal) closeBookingModal();
});

bookingForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const student = document.getElementById('student-name').value;
  alert(`Obrigado, ${student}! Seu pedido de agendamento foi enviado com sucesso. O explicador entrará em contacto em breve.`);
  closeBookingModal();
  bookingForm.reset();
});

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
  displayTutors(explicadores);
  window.addEventListener('scroll', revealOnScroll);
  revealOnScroll(); // Run once on load
});
